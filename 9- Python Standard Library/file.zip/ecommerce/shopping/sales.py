# from ecommerce.customer import contact # absolute import

# from ..customer import contact # relative import

# . will get you one level up

# print("Sales Initialized",__name__)

def calc_tax():
    pass


def calc_shipping():
    pass


if __name__ == "__main__":
    print("Sales started")
    calc_tax()